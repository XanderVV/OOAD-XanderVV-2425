﻿using System.Configuration;
using System.Windows;

namespace BenchmarkTool.AdminApp
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
