﻿using System.Windows;

// This WPF application uses theme resources
[assembly: ThemeInfo(
    ResourceDictionaryLocation.None, // These resources are used if a resource can't be found in the page
    ResourceDictionaryLocation.SourceAssembly) // This defines where the generic resource dictionary is located
] 